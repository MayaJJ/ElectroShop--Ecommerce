from django.apps import AppConfig


class Webapp1Config(AppConfig):
    name = 'webapp1'
